window.onload = function(){
  var container = document.getElementById('container');
  var list = document.getElementById('banner-list');
  var navs = document.getElementById('nav-list').getElementsByTagName('span');
  var navLeft = document.getElementById('nav-left');
  var navRight = document.getElementById('nav-right');
  var animated = false;
  var timer;
  var index = 1;
  function showButton(){
    for(var i=0;i<navs.length;i++){
        navs[i].classList.remove('active');
    }
    navs[index-1].classList.add('active');
  }
  for(var i=0;i<navs.length;i++){
    navs[i].onclick = function(){
      if(this.className === ' active'){
        return;
      }
      var myIndex = this.getAttribute('index');
      var offset = -1000 * (myIndex - index);
      if(!animated){
        animate(offset);
      }
      index = myIndex;
      showButton();
    }
  }
  function animate(offset){
    animated = true;
    var newLeft = parseInt(list.style.left) + offset;
    var times = 1000;
    var interval = 10;
    var speed = offset / (times/interval);//位移量

    function go(){
      if( (speed < 0 && parseInt(list.style.left) > newLeft) || (speed > 0 && parseInt(list.style.left) < newLeft) ){
        list.style.left = parseInt(list.style.left) + speed + 'px';
        setTimeout(go,interval);
      }else{
        animated = false;
        list.style.left = newLeft + 'px';
        if (newLeft > -1000) {
          list.style.left = -5000 + 'px';
        }
        if (newLeft < -5000) {
          list.style.left = -1000 + 'px';
        }
      }
    }
    go();
  }
  function play(){
    timer = setInterval(function(){
      navLeft.onclick();
    },3000);
  }
  function stop(){
    clearInterval(timer);
  }
  navLeft.onclick = function(){
    if(index == 5){
      index=1;
    }else{
      index++;
    }
    showButton();
    if(!animated){
      animate(-1000);
    }
  }
  navRight.onclick = function(){
    if(index == 1){
      index=5;
    }else{
      index--;
    }
    showButton();
    if(!animated){
      animate(1000);
    }
  }
  container.onmouseenter = function(){
    stop();
  }
  container.onmouseleave = function(){
    play();
  };
  play();
}
